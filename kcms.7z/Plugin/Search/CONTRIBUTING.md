Contributing
============

This repository follows the [CakeDC Plugin Standard](http://cakedc.com/plugins). If you'd like to contribute new features, enhancements or bug fixes to the plugin, please read our [Contribution Guidelines](http://cakedc.com/plugins) for detailed instructions.